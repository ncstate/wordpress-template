<?php 
/**
 * Plugin Name: RSS App
 * Plugin URI: https://github.com/csthomp89/rss-app
 * Description: Aggregates RSS feeds and allows you to choose which stories to include in output feed.
 * Version: 1.0
 * Author: Scott Thompson, College of Sciences, NC State University
 * Author URI: http://sciences.ncsu.edu
 * License: MIT
 */

/** Step 2 (from text above). */
add_action( 'admin_menu', 'rss_app_plugin_menu' );
$rss_app_feed_url = site_url() . '/wp-content/plugins/rss_app/feed.php';

/** Step 1. */
function rss_app_plugin_menu() {
	add_menu_page( "News (RSS)", "News (RSS)", 'manage_options', 'rss-app', 'rss_app_plugin_options');
	add_submenu_page( 'rss-app', 'RSS App Feeds', 'Source Feeds', 'manage_options', 'source_feeds', 'rss_app_source_feeds');
	add_submenu_page( 'rss-app', 'RSS App Settings', 'Settings', 'manage_options', 'settings', 'rss_app_settings');
	//add_options_page( 'My Plugin Options', 'My Plugin', 'manage_options', 'my-unique-identifier', 'my_plugin_options' );
}

/** Step 3. */
function rss_app_plugin_options() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	echo '<div class="wrap">';
	include 'select_stories.php';
	echo '</div>';
}

function rss_app_source_feeds() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	echo '<div class="wrap">';
	include 'source_feed.php';
	echo '</div>';
}

function rss_app_settings() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	echo '<div class="wrap">';
	echo '<h2>Update Available Stories</h2>';
	echo '<button onclick="refresh_feeds()" class="refresh-feeds">Refresh Feeds</button><br /><br />';
	echo '<h2>Your output RSS feed</h2><br /><a href="' . site_url() . '/wp-content/plugins/rss_app/feed.php">' . site_url() . '/wp-content/plugins/rss_app/feed.php</a>';
	echo '</div>';
	
	add_option('rss-app-feed-url', site_url() . '/wp-content/plugins/rss_app/feed.php');
	
	echo '
		<script type="text/javascript">
			function refresh_feeds() {
				jQuery.get("/wp-content/plugins/rss_app/load_feeds.php", function() {
					jQuery(".refresh-feeds").html("Feeds refreshed");
				});
			}
		</script>
	';
}